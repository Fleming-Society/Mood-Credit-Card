#include <MAX3010x.h>
#include "filters.h"

#define LED1 A0
#define LED2 A1
#define LED3 A2
#define LED4 A3
#define LED5 A4

// Sensor (adjust to your sensor type)
MAX30105 sensor;
const auto kSamplingRate = sensor.SAMPLING_RATE_3200SPS;
const float kSamplingFrequency = 400.0;

// Finger Detection Threshold and Cooldown
const unsigned long kFingerThreshold = 10000;
const unsigned int kFingerCooldownMs = 500;

// Edge Detection Threshold (decrease for MAX30100)
const float kEdgeThreshold = -2000.0;

// Filters
const float kLowPassCutoff = 5.0;
const float kHighPassCutoff = 0.5;

// Averaging
const bool kEnableAveraging = true;
const int kAveragingSamples = 5;
const int kSampleThreshold = 5;

// BPM as global var
int bpm_out = 0;

int led1state, led2state, led3state, led4state, led5state = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("Serial start");

  if (sensor.begin() && sensor.setSamplingRate(kSamplingRate)) {
    Serial.println("Sensor initialized");
  } else {
    Serial.println("Sensor not found");
    while (1)
      ;
  }
}

// Filter Instances
HighPassFilter high_pass_filter(kHighPassCutoff, kSamplingFrequency);
LowPassFilter low_pass_filter(kLowPassCutoff, kSamplingFrequency);
Differentiator differentiator(kSamplingFrequency);
MovingAverageFilter<kAveragingSamples> averager;

// Timestamp of the last heartbeat
long last_heartbeat = 0;

// Timestamp for finger detection
long finger_timestamp = 0;
bool finger_detected = false;

// Last diff to detect zero crossing
float last_diff = NAN;
bool crossed = false;
long crossed_time = 0;

void loop() {
  // Serial.println("debug");
  auto sample = sensor.readSample(1000);
  float current_value = sample.red;

  // Detect Finger using raw sensor value
  if (sample.red > kFingerThreshold) {
    if (millis() - finger_timestamp > kFingerCooldownMs) {
      finger_detected = true;
    }
  } else {
    // Reset values if the finger is removed
    differentiator.reset();
    averager.reset();
    low_pass_filter.reset();
    high_pass_filter.reset();

    finger_detected = false;
    finger_timestamp = millis();
  }

  if (finger_detected) {
    current_value = low_pass_filter.process(current_value);
    current_value = high_pass_filter.process(current_value);
    float current_diff = differentiator.process(current_value);

    // Valid values?
    if (!isnan(current_diff) && !isnan(last_diff)) {

      // Detect Heartbeat - Zero-Crossing
      if (last_diff > 0 && current_diff < 0) {
        crossed = true;
        crossed_time = millis();
      }

      if (current_diff > 0) {
        crossed = false;
      }

      // Detect Heartbeat - Falling Edge Threshold
      if (crossed && current_diff < kEdgeThreshold) {
        if (last_heartbeat != 0 && crossed_time - last_heartbeat > 300) {
          // Show Results
          int bpm = 60000 / (crossed_time - last_heartbeat);
          if (true) {
            Serial.print("BPM raw:");
            Serial.println(bpm);
            bpm_out = bpm;
            // Average?
            if (kEnableAveraging) {
              int average_bpm = averager.process(bpm);

              // Show if enough samples have been collected
              if (averager.count() > kSampleThreshold) {
                Serial.print("avg Heart Rate (avg, bpm): ");
                Serial.println(average_bpm);
                bpm_out = average_bpm;
              }
            } else {
              Serial.print("Heart Rate (current, bpm): ");
              Serial.println(bpm);
              bpm_out = bpm;
            }
          }
          // Serial.println(bpm);
        }

        crossed = false;
        last_heartbeat = crossed_time;
      }
      // led_indication(bpm_out);
      // Serial.println(bpm_out);
    }

    last_diff = current_diff;
  }
}


void led_indication(int bpm) {

int val = 10;

  if (bpm > 150) {
    led1state = val;
    led2state = val;
    led3state = val;
    led4state = val;
    led5state = val;
  } else if (bpm >= 95) {
    led1state = val;
    led2state = val;
    led3state = val;  
    led4state = val;
    led5state = 0;
  } else if (bpm >= 85) {
    led1state = val;
    led2state = val;
    led3state = val;
    led4state = 0;
    led5state = 0;
  } else if (bpm >= 80) {
    led1state = val;
    led2state = val;
    led3state = 0;
    led4state = 0;
    led5state = 0;
  } else if (bpm >= 50) {
    led1state = val;
    led2state = 0;
    led3state = 0;
    led4state = 0;
    led5state = 0;
  } else {
    led1state = 0;
    led2state = 0;
    led3state = 0;
    led4state = 0;
    led5state = 0;
  }
  analogWrite(LED1, led1state);
  analogWrite(LED2, led2state);
  analogWrite(LED3, led3state);
  analogWrite(LED4, led4state);
  analogWrite(LED5, led5state);
}